const status=document.querySelector('#status'), button=document.querySelector('#confirm')
const key='sumaiStationReviewV1'
const supported=()=>chrome.runtime.getManifest().background?.service_worker==='station-review-worker.js' &&
 chrome.runtime.getManifest().permissions?.includes('nativeMessaging')
let pending=false, checking=false, tries=0
async function check(){
 if(checking || pending)return
 checking=true
 try{
  if(!(await chrome.storage.local.get(key))[key])return
  if(!supported())return
  const r=await chrome.runtime.sendMessage({type:'SUMAI_STATION_STATUS'}).catch(()=>null)
  if(r?.status==='ready'||r?.status==='searching'){
    status.textContent=r.status==='ready'?'已就绪。回到 Codex 或 Claude Code，说出找房需求即可。此页可以关闭。':'正在查询 REINS。结果会回到发起查询的对话。'
    button.hidden=true;tries=0
  }else{
    tries++
    status.textContent=tries<5?'正在连接本机助手……':'本机助手尚未连上，本次没有查询结果。'
    button.hidden=tries<5;button.textContent='重新连接'
  }
 }finally{checking=false}
}
button.onclick=async()=>{
 if(pending)return
 pending=true;button.disabled=true
 try{
  await chrome.storage.local.set({sumaiStationEnabledV1:true,[key]:true})
  if(!supported()){status.textContent='正在启用插件；若 Chrome 显示权限确认，请核对后确认。';chrome.runtime.reload();return}
  await chrome.runtime.sendMessage({type:'SUMAI_STATION_ENABLE'})
  tries=0
 }catch{status.textContent='未能连接，点击重试。';button.textContent='重新连接'}
 finally{pending=false;button.disabled=false}
 await check()
}
void check();setInterval(check,1500)
