import { createHash } from 'node:crypto'
import { spawnSync } from 'node:child_process'
import { createReadStream } from 'node:fs'
import { cp, lstat, mkdir, mkdtemp, readFile, readdir, rename, rm } from 'node:fs/promises'
import path from 'node:path'

const source = path.join(import.meta.dirname, 'package')
async function sha(file) {
  const hash = createHash('sha256')
  for await (const chunk of createReadStream(file)) hash.update(chunk)
  return hash.digest('hex')
}

async function entries(dir, prefix = '') {
  const files = []
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    const name = prefix + entry.name
    if (entry.isDirectory()) files.push(...await entries(path.join(dir, entry.name), name + '/'))
    else if (entry.isFile()) files.push(name)
    else throw new Error('Linked or unsupported entry: ' + name)
  }
  return files
}

async function verify(dir, manifest) {
  if (!(await lstat(dir)).isDirectory()) throw new Error('Expected a project-local directory: ' + dir)
  const files = await entries(dir)
  if (files.length !== Object.keys(manifest).length) throw new Error('Unexpected install contents: ' + dir)
  for (const name of files) {
    if (!Object.hasOwn(manifest, name) || await sha(path.join(dir, name)) !== manifest[name]) {
      throw new Error('File verification failed: ' + name)
    }
  }
  const node = path.join(dir, 'runtime', 'node.exe')
  for (const args of [['--version'], [path.join(dir, 'scripts', 'toolkit.mjs'), '--help']]) {
    const result = spawnSync(node, args, { windowsHide: true, encoding: 'utf8' })
    if (result.status !== 0 || !result.stdout.trim() || (args.length === 1 && result.stdout.trim() !== 'v24.22.3')) {
      throw new Error('Self-test failed: ' + args.at(-1) + ' ' + (result.stderr || ''))
    }
  }
}

async function main() {
  const [project, host = 'Codex', ...rest] = process.argv.slice(2)
  if (!project || rest.length || !['Codex', 'Claude'].includes(host) || process.platform !== 'win32' || process.arch !== 'x64') {
    throw new Error('Usage on Windows x64: node.exe install.mjs PROJECT [Codex|Claude]')
  }
  if (!(await lstat(project)).isDirectory()) throw new Error('Choose an existing project directory.')
  const inventory = path.join(import.meta.dirname, 'files.json')
  if (await sha(inventory) !== 'b4a51dec0535e426c3bf61b41e1d31dbb5b98fe5dd7d1a47cd84cac4d68bc59c') throw new Error('Inventory verification failed.')
  const manifest = JSON.parse(await readFile(inventory, 'utf8'))
  const scope = path.resolve(project, host === 'Claude' ? '.claude' : '.agents')
  const skills = path.join(scope, 'skills')
  for (const folder of [scope, skills]) {
    await mkdir(folder, { recursive: true })
    if (!(await lstat(folder)).isDirectory()) throw new Error('Linked skill directory: ' + folder)
  }
  const dest = path.join(skills, 'sumai-property-toolkit')
  const existing = await lstat(dest).catch(error => {
    if (error.code !== 'ENOENT') throw error
  })
  if (existing) await verify(dest, manifest)
  else {
    const stage = await mkdtemp(path.join(scope, 'sumai-stage-'))
    const unpacked = path.join(stage, 'package')
    try {
      await cp(source, unpacked, { recursive: true, force: false, errorOnExist: true })
      await verify(unpacked, manifest)
      await rename(unpacked, dest)
    } finally {
      await rm(stage, { recursive: true, force: true })
    }
  }
  console.log(JSON.stringify({ status: existing ? 'already-installed' : 'installed',
    candidate: '20261116-25', agent: host, skill: path.join(dest, 'SKILL.md'),
    node: path.join(dest, 'runtime', 'node.exe'), browser: 'requires-authorized-browser-check' }))
}
main().catch(error => { console.error(error.message); process.exitCode = 1 })
