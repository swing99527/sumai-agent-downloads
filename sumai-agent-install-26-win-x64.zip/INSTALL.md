# 住まいAgent 浏览器试用版 26

适用 Windows 11 x64、业务允许使用的 Chrome、具有本机执行和读图能力的 Codex。安装包自带 Node 24；PDF 预览需 Codex Desktop 的 PDF 运行时或 pdftoppm。一个项目处理一批站线。

用随包的 package/runtime/node.exe 执行 install.mjs，将当前项目绝对路径与 Codex 作为两个参数。读取 JSON 返回的 skill、client、browser.extension、browser.profile。宿主的 shell 可以直接调用 client，本对话可继续。已有不同版本的同名 Skill 时停止，使用独立空项目。

首次启用使用专用的 Chrome 配置，避免操作客户已有浏览器配置。请启动已安装的 Google Chrome，参数为 `--user-data-dir=返回的browser.profile`、`--no-first-run` 和 `chrome://extensions`。这是待验证的本地加载试用扩展。使用 Chrome 官方扩展管理页的「开发者模式 → 加载已解压的扩展」选择返回的 browser.extension。可用宿主的原生窗口工具协助选择目录；授权提示由用户本人确认。组织策略不允许时报告阻塞。不要改企业策略、浏览器配置文件或复制其他配置的登录状态。

Chrome 会打开找房助手的说明页；用户确认启用本项目的检索和图纸保存后，使用随包 node 执行 `station.cjs 当前项目 status`。只有 connected=true 才报告已连接。读取项目内 SKILL.md，等待客户需求。真实查询在这个浏览器配置中进行，REINS 登录、验证码和规程确认由用户本人完成。
