import { spawnSync } from 'node:child_process'
import path from 'node:path'
import { setup } from './package/browser/browser-project.mjs'
const [project,agent='Codex']=process.argv.slice(2)
const installed=spawnSync(process.execPath,[path.join(import.meta.dirname,'install-skill.mjs'),project,agent],{encoding:'utf8',windowsHide:true})
if(installed.status!==0)throw Error(installed.stderr || 'Skill installation failed')
const result=JSON.parse(installed.stdout)
const skill=path.dirname(result.skill)
const browser=await setup(project,skill)
console.log(JSON.stringify({...result,candidate:'26',browser,client:path.join(skill,'browser','station.cjs')}))
