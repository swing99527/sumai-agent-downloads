import {mkdir,lstat,readFile,writeFile} from 'node:fs/promises'
import path from 'node:path'

const start='# BEGIN SUMAI MANAGED MCP',end='# END SUMAI MANAGED MCP'
export async function configureHost(project,host,node,server){
 const codex=host==='Codex'
 if(!codex&&host!=='Claude')throw Error('Unsupported host')
 const dir=codex?path.join(project,'.codex'):project
 await mkdir(dir,{recursive:true})
 if(!(await lstat(dir)).isDirectory())throw Error('Linked host configuration directory refused')
 const file=path.join(dir,codex?'config.toml':'.mcp.json')
 const stat=await lstat(file).catch(e=>{if(e.code!=='ENOENT')throw e})
 if(stat&&!stat.isFile())throw Error('Linked host configuration refused')
 const old=stat?await readFile(file,'utf8'):''
 const args=[server,project]
 let next
 if(codex){
  const block=[start,'[mcp_servers.sumai]',`command = ${JSON.stringify(node)}`,`args = ${JSON.stringify(args)}`,'startup_timeout_sec = 30','tool_timeout_sec = 180',end].join('\n')
  const i=old.indexOf(start),j=old.indexOf(end)
  if(i>=0||j>=0){
   if(i<0||j<i||old.indexOf(start,i+1)>=0||old.indexOf(end,j+1)>=0)throw Error('Conflicting Sumai configuration markers')
   next=old.slice(0,i)+block+old.slice(j+end.length)
  }else{
   if(/\bsumai\b/i.test(old))throw Error('An existing Sumai configuration requires review')
   next=old+(old&&!old.endsWith('\n')?'\n':'')+'\n'+block+'\n'
  }
 }else{
  const config=old?JSON.parse(old.replace(/^\uFEFF/,'')):{}
  if(!config||typeof config!=='object'||Array.isArray(config))throw Error('Invalid MCP configuration')
  config.mcpServers??={}
  if(typeof config.mcpServers!=='object'||Array.isArray(config.mcpServers))throw Error('Invalid MCP servers')
  const value={type:'stdio',command:node,args}
  if(config.mcpServers.sumai&&JSON.stringify(config.mcpServers.sumai)!==JSON.stringify(value))throw Error('An existing Sumai configuration requires review')
  config.mcpServers.sumai=value
  next=JSON.stringify(config,null,2)+'\n'
 }
 if(next!==old){
  if(stat){
   if(await readFile(file,'utf8')!==old)throw Error('Host configuration changed during installation')
   // Only this project-local file is changed. Keep a first-install rollback copy.
   await writeFile(file+'.before-sumai',old,{flag:'wx',mode:0o600}).catch(e=>{if(e.code!=='EEXIST')throw e})
  }
  await writeFile(file,next,{flag:stat?'w':'wx',mode:0o600})
 }
 return {file,server:'sumai',next:'Use the host supported MCP reload or start a new conversation in this project; approve project trust/tool permissions if requested.'}
}
