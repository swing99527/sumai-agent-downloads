import { spawn } from 'node:child_process'
import { access } from 'node:fs/promises'
import path from 'node:path'
import { createInterface } from 'node:readline'
import { isDeepStrictEqual } from 'node:util'

// Only return allowlisted setup facts. The host response may contain unrelated secrets.
export function summarizeConfiguration(result, project) {
  const normalize = value => {
    const absolute = path.resolve(value)
    return process.platform === 'win32' ? absolute.toLowerCase() : absolute
  }
  const layer = result?.layers?.find(item => item.name?.type === 'project' &&
    typeof item.name.dotCodexFolder === 'string' &&
    normalize(item.name.dotCodexFolder) === normalize(path.join(project, '.codex')))
  if (!layer) return { status: 'unverified', reason: 'project_layer_not_reported' }
  if (layer.disabledReason) return {
    status: /trust/i.test(layer.disabledReason) ? 'project_trust_required' : 'project_config_disabled',
    reason: /trust/i.test(layer.disabledReason) ? 'host_disabled_untrusted_project' : 'host_disabled_project_layer',
  }
  const local = layer.config?.mcp_servers?.sumai
  const effective = result.config?.mcp_servers?.sumai
  if (!local || !effective) return { status: 'configuration_missing', reason: 'sumai_not_effective' }
  if (effective.enabled === false) return { status: 'project_config_disabled', reason: 'sumai_disabled' }
  if (local.command !== effective.command || JSON.stringify(local.args) !== JSON.stringify(effective.args))
    return { status: 'configuration_conflict', reason: 'effective_server_differs' }
  return { status: 'configuration_effective', reason: 'native_tool_response_still_required' }
}

async function hostCommand(command) {
  if (command) return command
  const mac = '/Applications/Codex.app/Contents/Resources/codex'
  return process.platform === 'darwin' && await access(mac).then(() => true, () => false)
    ? mac : process.platform === 'win32' ? 'codex.exe' : 'codex'
}

// One short-lived official app-server process for a few protocol calls, never a customer chat.
async function withHost(project, { command, args = ['app-server', '--stdio'], timeoutMs = 12000 } = {}, run) {
  command = await hostCommand(command)
  return new Promise(resolve => {
    let finished = false, sequence = 0, result
    const pending = new Map()
    const child = spawn(command, args, { cwd: project, windowsHide: true, stdio: ['pipe', 'pipe', 'ignore'] })
    const lines = createInterface({ input: child.stdout })
    const timer = setTimeout(() => finish({ status: 'unverified', reason: 'host_diagnostic_timeout' }), timeoutMs)
    function finish(value) {
      if (finished) return
      finished = true
      clearTimeout(timer)
      for (const request of pending.values()) request.reject(Error('host_closed'))
      pending.clear()
      lines.close()
      child.stdin.end()
      child.kill()
      result = value
    }
    const unavailable = () => finish({ status: 'unverified', reason: 'host_diagnostic_unavailable' })
    const send = message => child.stdin.write(JSON.stringify(message) + '\n')
    const call = (method, params) => new Promise((resolve, reject) => {
      const id = ++sequence
      pending.set(id, { resolve, reject })
      send({ id, method, params })
    })
    child.stdin.on('error', unavailable)
    child.on('error', unavailable)
    // Resolve only after exit so the project directory is not left busy.
    child.on('close', () => { unavailable(); resolve(result) })
    lines.on('line', line => {
      let message
      try { message = JSON.parse(line) } catch { return }
      const request = pending.get(message.id)
      if (!request) return
      pending.delete(message.id)
      if (message.error) request.reject(Error('host_protocol_unavailable'))
      else request.resolve(message.result)
    })
    child.on('spawn', async () => {
      try {
        await call('initialize', { clientInfo: { name: 'sumai-install-diagnostic', version: '1' }, capabilities: { experimentalApi: true } })
        send({ method: 'initialized' })
        finish(await run(call))
      } catch (error) {
        finish({ status: 'unverified', reason: /^host_[a-z_]+$/.test(error.message) ? error.message : 'host_protocol_unavailable' })
      }
    })
  })
}

const readConfig = (call, project) => call('config/read', { cwd: project, includeLayers: true })

// Read-only: initialize and config/read only.
export function diagnoseCodex(project, options) {
  return withHost(project, options, async call => summarizeConfiguration(await readConfig(call, project), project))
}

const userLayer = state => state?.layers?.find(layer => layer.name?.type === 'user' && layer.name.profile == null)
const samePath = (a, b) => process.platform === 'win32'
  ? path.resolve(a).toLowerCase() === path.resolve(b).toLowerCase() : path.resolve(a) === path.resolve(b)
function withoutTrust(config, key) {
  const rest = structuredClone(config)
  if (rest.projects?.[key]) {
    delete rest.projects[key].trust_level
    if (!Object.keys(rest.projects[key]).length) delete rest.projects[key]
    if (!Object.keys(rest.projects).length) delete rest.projects
  }
  return rest
}

// Call only after the person approved running local tools in this exact PROJECT.
// Writes one key, projects.<PROJECT>.trust_level, through Codex's official
// config API with optimistic versioning, then proves nothing else changed.
export async function applyProjectTrust(project, options) {
  const result = await withHost(project, { timeoutMs: 15000, ...options }, async call => {
    const before = await readConfig(call, project)
    const prior = summarizeConfiguration(before, project)
    if (prior.status === 'configuration_effective') return { status: 'already_effective', hostDiagnostic: prior }
    if (prior.status !== 'project_trust_required') return { status: 'blocked', reason: prior.status }
    const user = userLayer(before)
    if (!user?.version || !user.config || !user.name.file) return { status: 'blocked', reason: 'user_config_version_unavailable' }
    const keys = Object.keys(user.config.projects ?? {}).filter(key => samePath(key, project))
    if (keys.length > 1) return { status: 'blocked', reason: 'ambiguous_project_trust_entries' }
    const key = keys[0] ?? project
    // A dot would split the key path; leave such projects to the host's own trust prompt.
    if (key.includes('.')) return { status: 'blocked', reason: 'project_path_needs_host_trust_prompt' }
    await call('config/value/write', { keyPath: `projects.${key}.trust_level`, value: 'trusted', mergeStrategy: 'upsert',
      filePath: user.name.file, expectedVersion: user.version })
    const after = await readConfig(call, project)
    const updated = userLayer(after)
    return {
      status: 'trusted',
      scopedTrustVerified: updated?.config?.projects?.[key]?.trust_level === 'trusted',
      otherUserSettingsPreserved: isDeepStrictEqual(withoutTrust(user.config, key), withoutTrust(updated?.config ?? {}, key)),
      hostDiagnostic: summarizeConfiguration(after, project),
    }
  })
  return result.status === 'unverified' ? { status: 'blocked', reason: result.reason } : result
}
