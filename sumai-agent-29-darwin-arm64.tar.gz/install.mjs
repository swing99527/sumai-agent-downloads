import {createHash} from 'node:crypto'
import {execFile,spawnSync} from 'node:child_process'
import {promisify} from 'node:util'
import {cp,lstat,mkdir,mkdtemp,readFile,readdir,realpath,rename,rm,writeFile} from 'node:fs/promises'
import path from 'node:path'
import {setup} from './package/browser/workspace-setup.mjs'
import {configureHost} from './host-config.mjs'
import {applyProjectTrust,diagnoseCodex} from './host-readiness.mjs'
const execute=promisify(execFile)
const sha=bytes=>createHash('sha256').update(bytes).digest('hex')
async function entries(dir,prefix=''){
 const result=[]
 for(const item of await readdir(dir,{withFileTypes:true})){
  const name=prefix+item.name
  if(item.isDirectory())result.push(...await entries(path.join(dir,item.name),name+'/'))
  else if(item.isFile())result.push(name)
  else throw Error('Linked package entry refused')
 }
 return result
}
async function verify(dir,manifest){
 if(!(await lstat(dir)).isDirectory())throw Error('Linked installation directory refused')
 const files=await entries(dir)
 if(files.length!==Object.keys(manifest).length)throw Error('Unexpected installation files')
 for(const name of files)if(!Object.hasOwn(manifest,name)||sha(await readFile(path.join(dir,name)))!==manifest[name])throw Error('Package integrity failure: '+name)
}
// Only refresh the published 2026-11-25 entry documents. Every runtime and
// knowledge file must already match this package. Preserve the directory so
// existing MCP paths, running processes, pairing and cases do not move.
async function refreshEntry(destination,source,manifest,scope){
 if(!(await lstat(destination)).isDirectory())throw Error('Linked installation directory refused')
 const legacy={
  'README.md':'7358ad9115ef0f05e4eab634ca0607136065ae3c2e8ead96f0a16ff882f516e3',
  'agents/openai.yaml':null,
  'SKILL.md':'cc7fe37d3f1cd309ac6261027dab32381687145a1a3988afbcfdc7e53850c628',
 }
 const compatible={...manifest},changes=[]
 for(const [name,previous] of Object.entries(legacy)){
  const file=path.join(destination,name)
  const stat=await lstat(file).catch(e=>{if(e.code!=='ENOENT')throw e})
  if(stat&&!stat.isFile())throw Error('Linked entry document refused: '+name)
  const before=stat?await readFile(file):null,digest=before===null?null:sha(before)
  if(digest===manifest[name])continue
  if(digest!==previous)throw Error('Locally changed or unsupported entry document preserved: '+name)
  if(digest===null)delete compatible[name];else compatible[name]=digest
  changes.push({name,before})
 }
 await verify(destination,compatible)
 if(!changes.length)return null
 const backup=await mkdtemp(path.join(scope,'sumai-entry-backup-'))
 const stage=await mkdtemp(path.join(scope,'sumai-entry-stage-'))
 try{
  for(const {name,before} of changes){
   if(before!==null){const file=path.join(backup,name);await mkdir(path.dirname(file),{recursive:true});await writeFile(file,before,{flag:'wx'})}
   const file=path.join(stage,name);await mkdir(path.dirname(file),{recursive:true});await cp(path.join(source,name),file,{errorOnExist:true,force:false})
  }
  await verify(destination,compatible)
  // SKILL.md is last; an interrupted update can safely finish on the next run.
  for(const {name} of changes){const file=path.join(destination,name);await mkdir(path.dirname(file),{recursive:true});await rename(path.join(stage,name),file)}
  await verify(destination,manifest)
 }finally{await rm(stage,{recursive:true,force:true})}
 return {backup,files:changes.map(({name})=>name)}
}
async function main(){
 const started=performance.now(),timingsMs={}
 let mark=started
 const measured=name=>{const now=performance.now();timingsMs[name]=Math.round(now-mark);mark=now}
 let [project,host='Codex',mode,...extra]=process.argv.slice(2)
 const supported=(process.platform==='win32'&&process.arch==='x64'&&['Codex','Claude'].includes(host))||(process.platform==='darwin'&&process.arch==='arm64'&&host==='Codex')
 if(!project||extra.length||!supported||!['--prepare-browser','--approve-project-trust',undefined].includes(mode))throw Error('Supported: install.mjs PROJECT Codex|Claude [--prepare-browser|--approve-project-trust]')
 if(mode==='--approve-project-trust'&&host!=='Codex')throw Error('Project trust command is for Codex only')
 if(process.platform==='win32'&&/[\\/]#!sandbox\./i.test(process.env.LOCALAPPDATA??''))throw Error('Windows redirected LOCALAPPDATA into a sandbox. Retry this same project installation with the host approved normal-user execution; no package or case files have been installed.')
 project=await realpath(project)
 if(!(await lstat(project)).isDirectory())throw Error('Existing project required')
 const bytes=await readFile(path.join(import.meta.dirname,'files.json'))
 if(sha(bytes)!=='53e10909f0220c17a50e7354731df8799263087ab50a1c4a7f732bb670de18e5')throw Error('Inventory integrity failure')
 const manifest=JSON.parse(bytes),source=path.join(import.meta.dirname,'package')
 await verify(source,manifest)
 measured('verifyPackage')
 const scope=path.join(project,host==='Codex'?'.agents':'.claude'),skills=path.join(scope,'skills')
 const destination=path.join(skills,'sumai-property-toolkit')
 if(mode==='--approve-project-trust'){
  // Separate invocation after explicit consent for this exact project. It
  // cannot install a package, open Chrome, or grant trust to another project.
  await verify(destination,manifest)
  const result=await applyProjectTrust(project)
  measured('approvedTrust')
  const verified=result.status==='already_effective'||(result.status==='trusted'&&result.scopedTrustVerified&&result.otherUserSettingsPreserved&&result.hostDiagnostic?.status==='configuration_effective')
  console.log(JSON.stringify({status:verified?'host-configured':'blocked',project,trust:result,
   nextAction:verified?'reload_native_mcp_once':'report_host_diagnostic',hostMcpVerified:false,browserConnected:false,
   timingsMs:{...timingsMs,total:Math.round(performance.now()-started)}}))
  if(!verified)process.exitCode=2
  return
 }
 for(const dir of [scope,skills]){await mkdir(dir,{recursive:true});if(!(await lstat(dir)).isDirectory())throw Error('Linked skill directory refused')}
 const exists=await lstat(destination).catch(e=>{if(e.code!=='ENOENT')throw e})
 let entryUpdate=null
 if(exists)entryUpdate=await refreshEntry(destination,source,manifest,scope)
 else{
  const stage=await mkdtemp(path.join(scope,'sumai-install-'))
  try{const unpacked=path.join(stage,'package');await cp(source,unpacked,{recursive:true});await verify(unpacked,manifest);await rename(unpacked,destination)}
  finally{await rm(stage,{recursive:true,force:true})}
 }
 const node=path.join(destination,'runtime',process.platform==='darwin'?'node':'node.exe')
 const self=spawnSync(node,['--version'],{encoding:'utf8',windowsHide:true})
 if(self.status!==0||self.stdout.trim()!=='v24.22.3')throw Error('Bundled Node self-test failed')
 const browser=await setup(project,destination,true,true)
 const mcp=await configureHost(project,host,node,path.join(destination,'browser','workspace-mcp.mjs'))
 measured('installAndConfigure')
 const [hostDiagnostic,browserPreparation]=await Promise.all([
  host==='Codex'?diagnoseCodex(project):{status:'unverified',reason:'use_native_host_reload'},
  mode==='--prepare-browser'?execute(node,[path.join(destination,'browser','store-connect.mjs'),browser.exchange,'--prepare-store'],{windowsHide:true,timeout:10000,maxBuffer:4096})
   .then(({stdout})=>JSON.parse(stdout)).catch(()=>({extension:'unverified',reason:'prepare_browser_failed_use_native_connect'})):{extension:'not_requested'},
 ])
 measured('hostAndBrowserPreparation')
 console.log(JSON.stringify({status:entryUpdate?'updated':exists?'already-installed':'installed',candidate:'29',host,skillName:'sumai',skill:path.join(destination,'SKILL.md'),entryUpdate,node,browser,mcp,
  browserPreparation,timingsMs:{...timingsMs,total:Math.round(performance.now()-started)},
  readiness:{filesVerified:true,hostConfigured:true,hostMcpVerified:false,browserConnected:false,
   hostDiagnostic,
   nextAction:hostDiagnostic.status==='project_trust_required'?'request_exact_project_trust':hostDiagnostic.status==='configuration_effective'||host==='Claude'?'reload_native_mcp_once':'report_host_diagnostic',
   approvedTrustCommand:hostDiagnostic.status==='project_trust_required'?{command:process.execPath,args:[path.join(import.meta.dirname,'install.mjs'),project,host,'--approve-project-trust'],requiresExplicitUserConsent:true}:undefined,
   next:'Installation files and host configuration are saved, but setup is NOT complete. In this same project obtain a real sumai.connection_status response from the host, then connect_browser if needed. If sumai tools are absent, diagnose project trust and host reload using supported host tools. Do not switch to Computer Use, a business CLI, or a nested MCP process and report installation success.'}}))
}
main().catch(error=>{console.error(error.message);process.exitCode=1})
