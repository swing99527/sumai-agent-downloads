import {createHash} from 'node:crypto'
import {spawnSync} from 'node:child_process'
import {cp,lstat,mkdir,mkdtemp,readFile,readdir,realpath,rename,rm} from 'node:fs/promises'
import path from 'node:path'
import {setup} from './package/browser/workspace-setup.mjs'
import {configureHost} from './host-config.mjs'
const sha=bytes=>createHash('sha256').update(bytes).digest('hex')
async function entries(dir,prefix=''){
 const result=[]
 for(const item of await readdir(dir,{withFileTypes:true})){
  const name=prefix+item.name
  if(item.isDirectory())result.push(...await entries(path.join(dir,item.name),name+'/'))
  else if(item.isFile())result.push(name)
  else throw Error('Linked package entry refused')
 }
 return result
}
async function verify(dir,manifest){
 if(!(await lstat(dir)).isDirectory())throw Error('Linked installation directory refused')
 const files=await entries(dir)
 if(files.length!==Object.keys(manifest).length)throw Error('Unexpected installation files')
 for(const name of files)if(!Object.hasOwn(manifest,name)||sha(await readFile(path.join(dir,name)))!==manifest[name])throw Error('Package integrity failure: '+name)
}
async function main(){
 let [project,host='Codex',...extra]=process.argv.slice(2)
 const supported=(process.platform==='win32'&&process.arch==='x64'&&['Codex','Claude'].includes(host))||(process.platform==='darwin'&&process.arch==='arm64'&&host==='Codex')
 if(!project||extra.length||!supported)throw Error('Supported: Windows x64 Codex/Claude; Apple Silicon Codex')
 if(process.platform==='win32'&&/[\\/]#!sandbox\./i.test(process.env.LOCALAPPDATA??''))throw Error('Windows redirected LOCALAPPDATA into a sandbox. Retry this same project installation with the host approved normal-user execution; no package or case files have been installed.')
 project=await realpath(project)
 if(!(await lstat(project)).isDirectory())throw Error('Existing project required')
 const bytes=await readFile(path.join(import.meta.dirname,'files.json'))
 if(sha(bytes)!=='bd34325e4392a9b11b3ff38a3a6040462c2b45bd14d42a3720103861e9146929')throw Error('Inventory integrity failure')
 const manifest=JSON.parse(bytes),source=path.join(import.meta.dirname,'package')
 await verify(source,manifest)
 const scope=path.join(project,host==='Codex'?'.agents':'.claude'),skills=path.join(scope,'skills')
 for(const dir of [scope,skills]){await mkdir(dir,{recursive:true});if(!(await lstat(dir)).isDirectory())throw Error('Linked skill directory refused')}
 const destination=path.join(skills,'sumai-property-toolkit')
 const exists=await lstat(destination).catch(e=>{if(e.code!=='ENOENT')throw e})
 if(exists)await verify(destination,manifest)
 else{
  const stage=await mkdtemp(path.join(scope,'sumai-install-'))
  try{const unpacked=path.join(stage,'package');await cp(source,unpacked,{recursive:true});await verify(unpacked,manifest);await rename(unpacked,destination)}
  finally{await rm(stage,{recursive:true,force:true})}
 }
 const node=path.join(destination,'runtime',process.platform==='darwin'?'node':'node.exe')
 const self=spawnSync(node,['--version'],{encoding:'utf8',windowsHide:true})
 if(self.status!==0||self.stdout.trim()!=='v24.22.3')throw Error('Bundled Node self-test failed')
 const browser=await setup(project,destination,true,true)
 const mcp=await configureHost(project,host,node,path.join(destination,'browser','workspace-mcp.mjs'))
 console.log(JSON.stringify({status:exists?'already-installed':'installed',candidate:'29',host,skill:path.join(destination,'SKILL.md'),node,browser,mcp}))
}
main().catch(error=>{console.error(error.message);process.exitCode=1})
