ObjC.import('PDFKit')
ObjC.import('AppKit')

function run(args) {
  if (args[0] === '--version') return 'Sumai PDFKit preview 1'
  const pageNumber = Number(args[0])
  const data = $.NSFileHandle.fileHandleWithStandardInput.readDataToEndOfFile
  const document = $.PDFDocument.alloc.initWithData(data)
  if (!document || !Number.isInteger(pageNumber) || pageNumber < 1 || pageNumber > Number(document.pageCount)) {
    throw Error('PDF page unavailable')
  }
  const page = document.pageAtIndex(pageNumber - 1)
  const bounds = page.boundsForBox($.kPDFDisplayBoxCropBox)
  const rotated = Number(page.rotation) % 180 !== 0
  const width = rotated ? bounds.size.height : bounds.size.width
  const height = rotated ? bounds.size.width : bounds.size.height
  const scale = 2450 / Math.max(width, height)
  const image = page.thumbnailOfSizeForBox($.NSMakeSize(Math.round(width * scale), Math.round(height * scale)), $.kPDFDisplayBoxCropBox)
  const bitmap = $.NSBitmapImageRep.imageRepWithData(image.TIFFRepresentation)
  const jpeg = bitmap.representationUsingTypeProperties($.NSBitmapImageFileTypeJPEG, $({NSImageCompressionFactor: 0.9}))
  if (!jpeg || Number(jpeg.length) < 2) throw Error('PDF page rendering failed')
  $.NSFileHandle.fileHandleWithStandardOutput.writeData(jpeg)
}
