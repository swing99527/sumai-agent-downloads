import fs from 'node:fs'
import path from 'node:path'
import { createHash, randomUUID } from 'node:crypto'

// Operates only on directories previously authorized and access-checked by the host.
const [action, unitArg, stageArg, listing, filename] = process.argv.slice(2)
const source = 'https://system.reins.jp/main/BK/GBK003100'
const hash = bytes => createHash('sha256').update(bytes).digest('hex')
function requireThat(value, code) { if (!value) throw new Error(code) }
function validFilename(name) {
  return typeof name === 'string' && path.basename(name) === name && !/[<>:"/\\|?*\x00-\x1f]/u.test(name) && /\.pdf$/i.test(name)
}
function relatedName(name, expected) {
  const actual = name.toLowerCase(), base = expected.toLowerCase()
  if (actual === base) return true
  const stem = base.slice(0,-4)
  return actual.startsWith(stem) && /^ \([1-9]\d*\)\.pdf$/.test(actual.slice(stem.length))
}
function directory(arg) {
  requireThat(arg && path.isAbsolute(arg), 'ABSOLUTE_DIRECTORY_REQUIRED')
  const dir = path.resolve(arg)
  requireThat(fs.statSync(dir).isDirectory() && path.relative(dir, fs.realpathSync.native(dir)) === '', 'UNEXPECTED_DIRECTORY')
  return dir
}
function isInside(parent, child) {
  const rel = path.relative(parent, child)
  return rel === '' || (!path.isAbsolute(rel) && rel !== '..' && !rel.startsWith('..' + path.sep))
}
function fileBytes(file, published = false) {
  const stat = fs.lstatSync(file, {bigint:true})
  requireThat(stat.isFile() && !stat.isSymbolicLink(), 'REGULAR_FILE_REQUIRED')
  if (stat.nlink !== 1n) {
    // A process can stop between publication and unlinking its private temporary name.
    const dir = path.dirname(file)
    const aliases = published ? fs.readdirSync(dir).filter(name => /^[0-9a-f-]{36}\.partial$/i.test(name)).filter(name => {
      const tmp = fs.lstatSync(path.join(dir,name), {bigint:true})
      return tmp.isFile() && tmp.dev === stat.dev && tmp.ino === stat.ino
    }) : []
    requireThat(1n + BigInt(aliases.length) === stat.nlink, 'UNEXPECTED_FILE_LINK')
  }
  return fs.readFileSync(file)
}
function publish(file, bytes) {
  const tmp = path.join(path.dirname(file), randomUUID() + '.partial')
  const fd = fs.openSync(tmp, 'wx', 0o600)
  try {
    try { fs.writeFileSync(fd, bytes); fs.fsyncSync(fd) } finally { fs.closeSync(fd) }
    // Link publishes a fully written file and refuses to replace an existing destination.
    fs.linkSync(tmp, file)
  } finally { fs.unlinkSync(tmp) }
}
function epoch(value) {
  requireThat(typeof value === 'string' && /Z$/.test(value) && Number.isFinite(Date.parse(value)), 'UTC_TIMESTAMP_REQUIRED')
  return Date.parse(value)
}
function run() {
  const unit = directory(unitArg)
  const intentFile = path.join(unit, 'drawing-intent.json')
  const receiptFile = path.join(unit, 'drawing-receipt.json')
  const original = path.join(unit, 'original.pdf')
  function stageDirectory() {
    const stage = directory(stageArg)
    requireThat(!isInside(unit,stage) && !isInside(stage,unit),'SEPARATE_STAGE_REQUIRED')
    return stage
  }
  if (action === 'prepare') {
    requireThat(/^\d{12}$/.test(listing) && validFilename(filename),'INVALID_SOURCE_IDENTITY')
    const stage = stageDirectory()
    requireThat(fs.readdirSync(unit).length === 0, 'NEW_UNIT_DIRECTORY_REQUIRED')
    const occupied = fs.readdirSync(stage).filter(name => relatedName(name,filename)).map(name => hash(name.toLowerCase()))
    const intent = { attempt: randomUUID(), listing, filename, occupied, source, stage, prepared: new Date().toISOString() }
    publish(intentFile, JSON.stringify(intent))
    return { status: 'ready_for_one_download', attempt: intent.attempt, listing, filename }
  }
  requireThat(action === 'receive' || action === 'resume', 'EXPECTED_PREPARE_RECEIVE_OR_RESUME')
  const intent = JSON.parse(fileBytes(intentFile,true))
  requireThat(/^\d{12}$/.test(intent.listing) && validFilename(intent.filename) && (intent.occupied === undefined || Array.isArray(intent.occupied)) && intent.source === source, 'INVALID_INTENT')
  const recorded = fs.existsSync(receiptFile)
  if (action === 'resume' && !recorded) return { status: 'event_missing_verify_or_reacquire', listing: intent.listing }
  requireThat(action !== 'receive' || !recorded, 'RECEIPT_EXISTS_USE_RESUME')
  const event = JSON.parse(recorded ? fileBytes(receiptFile,true) : fs.readFileSync(0,'utf8').replace(/^\uFEFF/, ''))
  requireThat(event.attempt === intent.attempt && event.listing === intent.listing && event.source === source && intent.source === source, 'EVENT_IDENTITY_MISMATCH')
  if (recorded) requireThat(/^[0-9a-f]{64}$/.test(event.sha256) && Number.isSafeInteger(event.bytes) && event.bytes >= 5, 'INVALID_RECEIPT')
  const reply = { status:'archived_unreviewed', listing:intent.listing, original:'original.pdf', receipt:'drawing-receipt.json' }
  if (fs.existsSync(original)) {
    requireThat(recorded, 'UNVERIFIED_ARCHIVE_EXISTS')
    const bytes = fileBytes(original,true)
    requireThat(bytes.length === event.bytes && hash(bytes) === event.sha256, 'ARCHIVE_MISMATCH')
    return { ...reply, reused:true }
  }
  const stage = stageDirectory()
  const landedName = path.basename(event.path)
  requireThat(path.relative(stage,intent.stage) === '' && path.isAbsolute(event.path) && event.path === path.normalize(event.path) && path.relative(stage,path.dirname(event.path)) === '' && relatedName(landedName,intent.filename), 'EVENT_PATH_MISMATCH')
  // Earlier intents only checked the exact source filename before the click.
  if (intent.occupied) requireThat(!intent.occupied.includes(hash(landedName.toLowerCase())), 'PREEXISTING_DOWNLOAD')
  else requireThat(landedName === intent.filename, 'UNKNOWN_EARLIER_DOWNLOAD')
  const start = epoch(event.started), end = epoch(event.completed)
  requireThat(start >= epoch(intent.prepared) && end >= start && end <= Date.now(), 'INVALID_EVENT_INTERVAL')
  const before = fs.lstatSync(event.path, {bigint:true})
  const bytes = fileBytes(event.path)
  const after = fs.lstatSync(event.path, {bigint:true})
  requireThat(before.ino === after.ino && before.size === after.size && before.mtimeNs === after.mtimeNs && before.ctimeNs === after.ctimeNs && BigInt(bytes.length) === after.size, 'DOWNLOAD_CHANGED')
  requireThat(after.birthtimeMs >= BigInt(start) && after.birthtimeMs <= BigInt(end) && after.mtimeMs >= BigInt(start) && after.mtimeMs <= BigInt(end), 'DOWNLOAD_TIME_MISMATCH')
  requireThat(bytes.subarray(0,5).toString() === '%PDF-', 'PDF_HEADER_MISMATCH')
  const sha256 = hash(bytes)
  if (recorded) requireThat(bytes.length === event.bytes && sha256 === event.sha256,'STAGED_BYTES_MISMATCH')
  else publish(receiptFile, JSON.stringify({attempt:intent.attempt, listing:intent.listing, source, path:event.path, started:event.started, completed:event.completed, bytes:bytes.length, sha256}))
  publish(original,bytes)
  return { ...reply, reused:false }
}
try { console.log(JSON.stringify(run())) }
catch (error) { console.error(JSON.stringify({status:'incomplete', reason:error.code ?? error.message})); process.exitCode=1 }
