/** Browser operations on the official host tab for a Tokyo resale-apartment search. */
export async function requestDetailDrawing(tab, intent) {
  const source = 'https://system.reins.jp/main/BK/GBK003100'
  if (!intent || typeof intent.attempt !== 'string' || !/^[0-9a-f-]{36}$/i.test(intent.attempt) ||
      !/^\d{12}$/.test(intent.listing) || typeof intent.filename !== 'string' ||
      /[\r\n]/u.test(intent.filename) || !/\.pdf$/iu.test(intent.filename)) {
    throw new Error('INVALID_DRAWING_INTENT')
  }
  if (await tab.url() !== source) throw new Error('WRONG_DETAIL_PAGE')
  const lines = (await tab.playwright.domSnapshot()).split(/\r?\n/u).map(line => line.trim())
  const matchesField = (section, label, value) => {
    const position = section.indexOf('- generic: ' + label)
    return position >= 0 && section.lastIndexOf('- generic: ' + label) === position &&
      section[position + 1] === '- generic: ' + value
  }
  const heading = '- heading "物件図面" [level=2]'
  const start = lines.indexOf(heading)
  const button = lines.findIndex((line, index) => index > start && /^- button "図面参照"(?: \[active\])?$/.test(line))
  const drawing = lines.slice(start + 1, button)
  const control = tab.playwright.getByRole('button', {name:'図面参照', exact:true})
  if (start < 0 || lines.lastIndexOf(heading) !== start || button <= start ||
      drawing.some(line => line.startsWith('- heading ')) ||
      !matchesField(lines, '物件番号', '"' + intent.listing + '"') ||
      !matchesField(drawing, 'ファイル名', intent.filename) || await control.count() !== 1 ||
      await tab.url() !== source) throw new Error('DRAWING_DETAIL_MISMATCH')
  const started = new Date().toISOString()
  const [download] = await Promise.all([
    tab.playwright.waitForEvent('download', {timeoutMs:20000}), control.click(),
  ])
  const landed = await download.path()
  if (!landed) throw new Error('DOWNLOAD_PATH_UNCONFIRMED')
  return {attempt:intent.attempt, listing:intent.listing, source, started,
    completed:new Date().toISOString(), path:landed}
}

function validateRequest(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) return ['request']
  const errors = []
  const fields = ['line','station','maxWalkMinutes','priceManYen','areaSqm','layouts',
    'builtFromYear','floorMin','ownership','occupancy','orientations']
  for (const key of Object.keys(input)) if (!fields.includes(key)) errors.push(key)
  for (const key of ['line','station']) {
    if (typeof input[key] !== 'string' || !input[key].trim() || input[key].trim() !== input[key] ||
      input[key].length > 64 || /[\r\n\t]/u.test(input[key])) errors.push(key)
  }
  if (!Number.isSafeInteger(input.maxWalkMinutes) || input.maxWalkMinutes < 1) errors.push('maxWalkMinutes')
  if (!Number.isSafeInteger(input.builtFromYear) || input.builtFromYear < 1000 || input.builtFromYear > 9999) errors.push('builtFromYear')
  if (!Number.isSafeInteger(input.floorMin) || input.floorMin < 1) errors.push('floorMin')
  for (const key of ['priceManYen','areaSqm']) {
    const range = input[key]
    if (!Array.isArray(range) || range.length !== 2 || ![range[0],range[1]].every(v =>
      Number.isFinite(v) && v > 0 && (key !== 'priceManYen' || Number.isSafeInteger(v))) ||
      range[0] > range[1]) errors.push(key)
  }
  const layouts = input.layouts
  if (!Array.isArray(layouts) || !layouts.length ||
      !Array.from(layouts).every(v => typeof v === 'string' && /^[1-9]\d?(?:DK|LDK)$/u.test(v)) ||
      new Set(layouts.map(v => v.match(/^\d+/u)[0])).size !== 1) errors.push('layouts')
  if (input.ownership !== '所有権') errors.push('ownership')
  if (input.occupancy !== '空室') errors.push('occupancy')
  const compass = ['北','北東','東','南東','南','南西','西','北西']
  if (!Array.isArray(input.orientations) || !input.orientations.length ||
      !Array.from(input.orientations).every(v => compass.includes(v))) errors.push('orientations')
  return errors
}

const formUrl = 'https://system.reins.jp/main/BK/GBK001210'
const roles = ['textbox', 'combobox', 'radio', 'checkbox']
const normalize = value => String(value ?? '').normalize('NFKC').trim()

// Reuse the REINS adapter's .p-label-title -> adjacent controls relationship.
// Read only rendered controls exposed by the host. Mutations use the host's locator actions.
async function readControls(pw, year) {
  const visible = roles.map(role => pw.getByRole(role)).reduce((a,b) => a.or(b))
  return visible.evaluateAll((elements, year) => {
    const groups = Array.from(document.querySelectorAll('.p-label-title')).map(label => ({
      name: label.textContent.normalize('NFKC').trim(),
      root: label.closest('.p-label')?.nextElementSibling,
      row: label.closest('.p-label')?.parentElement
    })).filter(group => group.root)
    const occurrences = new Map()
    for (const group of groups) {
      group.occurrence = occurrences.get(group.name) ?? 0
      occurrences.set(group.name, group.occurrence + 1)
      group.positions = new Map()
    }
    const indexes = new Map()
    return elements.map(element => {
      let group = groups.find(group => group.root.contains(element))
      if (!group) {
        // Date periods put the radio choices and their era/year/month/day boxes in sibling containers.
        const dateRows = groups.filter(g => ['登録年月日','変更年月日','成約年月日','成約登録年月日'].includes(g.name) &&
          g.row?.contains(element))
        if (dateRows.length === 1) group = dateRows[0]
      }
      const tag = element.tagName
      const checkable = element.type === 'radio' || element.type === 'checkbox'
      const role = tag === 'SELECT' ? 'combobox' : checkable ? element.type : 'textbox'
      const index = indexes.get(role) ?? 0
      indexes.set(role, index + 1)
      const choice = checkable ? (element.labels?.[0]?.innerText || element.parentElement.innerText).trim() : ''
      const value = tag === 'SELECT' ? (element.options[element.selectedIndex]?.text ?? '').trim()
        : checkable ? (element.checked ? choice : '') : element.value
      const position = group?.positions.get(role) ?? 0
      group?.positions.set(role, position + 1)
      const result = { role, index, group: group?.name ?? '', occurrence: group?.occurrence ?? 0,
        position, choice, value, checked: checkable && element.checked,
        unnamedSelection: tag === 'SELECT' && !value && Boolean(element.value),
        editable: !element.disabled && !element.readOnly }
      if (group && ['価格','売買価格','専有面積','間取部屋数','所在階','駅から徒歩'].includes(group.name)) {
        result.units = (group.root.innerText ?? '').normalize('NFKC').replace(/\s/g,'').slice(0,120)
      }
      if (tag === 'SELECT' && group?.name === '築年月' && result.position === 0) {
        result.yearChoice = Array.from(element.options).map(o => o.text.trim())
          .find(label => label.normalize('NFKC').startsWith(year + '年'))
      }
      return result
    })
  }, year)
}

async function currentPage(tab) {
  const url = new URL(await tab.url())
  const source = url.origin + url.pathname
  if (url.origin === 'https://system.reins.jp' &&
      await tab.playwright.getByRole('button', { name: 'ログイン', exact: true }).isVisible()) {
    return { status: 'auth_required', source }
  }
  if (source !== formUrl ||
      !await tab.playwright.getByText('売買検索条件入力', { exact: true }).isVisible()) {
    return { status: 'unexpected_page', source }
  }
  return { source }
}

// Group, position and unit checks bind each endpoint to its own rendered range.
function expectedControls(input) {
  const roomCount = input.layouts[0].match(/^\d+/u)[0]
  const spec = []
  function add(key, role, group, position, expected, unit) {
    spec.push({ key, role, group, position, expected: String(expected), unit })
  }
  function check(key, role, group, choice) {
    spec.push({ key, role, group, choice, expected: choice })
  }
  add('category','combobox','物件種別1',0,'売マンション')
  add('propertyType','combobox','物件種目1',0,'中古マンション')
  check('stock','radio','対象区分','在庫')
  check('used','radio','新築・中古区分','中古')
  add('line','textbox','沿線名',0,input.line)
  add('from','textbox','駅名',0,input.station)
  add('to','textbox','駅名',1,input.station)
  add('walkMax','textbox','駅から徒歩',0,input.maxWalkMinutes,'以内')
  add('walkUnit','combobox','駅から徒歩',0,'分')
  add('priceMin','textbox','価格',0,input.priceManYen[0],'万円')
  add('priceMax','textbox','価格',1,input.priceManYen[1],'万円')
  add('areaMin','textbox','専有面積',0,input.areaSqm[0],'m2')
  add('areaMax','textbox','専有面積',1,input.areaSqm[1],'m2')
  add('roomsMin','textbox','間取部屋数',0,roomCount,'室')
  add('roomsMax','textbox','間取部屋数',1,roomCount,'室')
  for (const kind of new Set(input.layouts.map(layout => layout.replace(/^\d+/u,'')))) {
    check('layout' + kind,'checkbox','間取タイプ',kind)
  }
  add('floorMin','textbox','所在階',0,input.floorMin,'階')
  add('builtYear','combobox','築年月',0,input.builtFromYear)
  check('ownership','radio','土地権利/借地権種類','所有権のみ')
  return spec
}

// Non-target settings actually observed in the licensed Tokyo inventory workflow.
// In particular, keep and report the site's company-name selection as part of the search scope.
const sourceSettings = new Map([
  ['並び順', ['最新順(最終更新年月日+物件番号)','▲']],
  ['商号の有無',['商号あり']], ['取引状況',['指定なし']],
  ['所在地名2',['前方']], ['建物名',['部分']],
  ['登録年月日',['指定なし(全期間)']], ['変更年月日',['指定なし(全期間)']],
  ['成約年月日',['1年以内']], ['成約登録年月日',['指定なし(全期間)']]
])

function inspect(controls, spec) {
  const assigned = new Set()
  const observed = {}
  const missing = []
  const conflicts = []
  const pending = []
  const settings = []
  for (const s of spec) {
    const matches = controls.filter(c => c.role === s.role && c.group === s.group &&
      c.occurrence === 0 && (s.choice ? normalize(c.choice) === s.choice : c.position === s.position))
    const c = matches[0]
    if (matches.length !== 1) { missing.push(s.key); continue }
    assigned.add(c)
    observed[s.key] = c.value
    if (s.unit) {
      const unitText = String(c.units ?? '')
      const note = unitText.match(/\(((?:戸建|マンション|外全|外一|土地)(?:\/(?:戸建|マンション|外全|外一|土地))*)\)$/u)
      // Only the observed property-class annotation is optional. Both endpoint units remain mandatory.
      const applicable = !note || note[1].split('/').includes('マンション')
      const parts = (note && applicable ? unitText.slice(0, note.index) : unitText).split(/[~〜]/u)
      const hasUnits = s.key === 'walkMax' ? parts.some(p => p.includes(s.unit))
        : parts.length === 2 && parts.every(p => p === s.unit)
      if (!hasUnits) { missing.push(s.key + ':unit'); continue }
    }
    const expected = s.key === 'builtYear' ? c.yearChoice : s.expected
    if (!expected) { missing.push(s.key + ':option'); continue }
    if (normalize(c.value) === normalize(expected)) continue
    if (c.value || !c.editable) { conflicts.push(s.key); continue }
    pending.push({ key: s.key, role: s.role, index: c.index, expected })
  }
  for (const c of controls) {
    if ((c.checked && !c.choice) || c.unnamedSelection) { conflicts.push(c.group || c.role); continue }
    if (assigned.has(c) || !c.value) continue
    const value = normalize(c.value)
    if (c.role === 'radio' && value === '指定なし' &&
        ['新築・中古区分','土地権利/借地権種類'].includes(c.group)) continue
    if (c.role === 'combobox' && !c.editable && value === '令和' &&
        ['登録年月日','変更年月日','成約年月日','成約登録年月日'].includes(c.group)) continue
    if (['radio','combobox'].includes(c.role) && sourceSettings.get(c.group)?.includes(value)) {
      settings.push({ field: c.group, value: c.value })
    } else {
      // Report which extra control affected the scope without copying its unrelated text.
      conflicts.push(c.group || c.role)
    }
  }
  if (!settings.some(s => s.field === '商号の有無')) missing.push('商号の有無')
  return { observed, pending, missing, conflicts, settings }
}

/** Prepare and re-read an authorized scope. Never submits the form or requests a count. */
export async function prepareResaleSearch(tab, input) {
  let writes = 0
  let source = null
  let state
  const finish = (status, issues = []) => ({
    status, issues, writes, source, observedAt: new Date().toISOString(),
    observed: state?.observed ?? {}, sourceSettings: state?.settings ?? [],
    detailChecks: status === 'form_prepared' ? {
      occupancy: input.occupancy, orientations: [...input.orientations],
      stationAccess: 'verify_station_and_minutes_on_same_route',
      introductionAvailability: 'verify_separately_from_vacancy'
    } : null
  })
  const invalid = validateRequest(input)
  if (invalid.length) return finish('unsupported_request', invalid)
  const spec = expectedControls(input)
  let lastWrite
  for (let step = 0; step <= spec.length; step++) {
    const page = await currentPage(tab)
    source = page.source
    if (page.status) return finish(page.status)
    state = inspect(await readControls(tab.playwright, input.builtFromYear), spec)
    if (state.missing.length) return finish('unrecognized_form', state.missing)
    if (state.conflicts.length) return finish('scope_conflict', state.conflicts)
    if (!state.pending.length) return finish('form_prepared')
    if (lastWrite && state.pending.some(p => p.key === lastWrite)) return finish('readback_mismatch', [lastWrite])
    const next = state.pending[0]
    if (step === spec.length) return finish('readback_mismatch', [next.key])
    const locator = tab.playwright.getByRole(next.role).nth(next.index)
    try {
      if (next.role === 'textbox') await locator.fill(next.expected)
      else if (next.role === 'combobox') await locator.selectOption({ label: next.expected })
      else await locator.check()
    } catch {
      // A timeout can occur after the page has changed. Read back; leave retry to the caller.
      const current = await currentPage(tab)
      source = current.source
      state = current.status ? undefined : inspect(await readControls(tab.playwright, input.builtFromYear), spec)
      return finish(current.status ?? 'interaction_interrupted', [next.key])
    }
    writes++
    lastWrite = next.key
  }
}
/** Read a visible result. Only the witnessed single-page format can close a scope. */
export async function readResaleResults(tab) {
  const listUrl = 'https://system.reins.jp/main/BK/GBK002100'
  const page = new URL(await tab.url())
  const source = page.origin + page.pathname
  if (source !== listUrl) return { status: 'unexpected_page', source }
  const visibleSnapshot = await tab.playwright.domSnapshot()
  const observedAt = new Date().toISOString()
  const after = new URL(await tab.url())
  if (after.href !== page.href) return { status: 'page_changed', observedAt }
  const lines = visibleSnapshot.normalize('NFKC').split(/\r?\n/u)
  const heading = '- heading "売買検索結果一覧(在庫)" [level=1]'
  if (!lines.includes(heading)) return { status: 'unexpected_page', source }
  const evidence = { source, observedAt, visibleSnapshot }
  const incomplete = reason => ({ status: 'needs_review', reason, evidence })
  const panels = lines.filter(l => l.startsWith('- tabpanel '))
  const panel = /^- tabpanel "売マンション\((\d+)件\)":$/u.exec(panels[0] ?? '')
  if (panels.length !== 1 || !panel ||
      !lines.includes('  - tab "売マンション(' + panel[1] + '件)" [selected]')) return incomplete('category')
  const start = lines.indexOf(panels[0]) + 1
  const end = lines.findIndex((line, i) => i >= start && line.startsWith('- '))
  const body = lines.slice(start, end < 0 ? undefined : end)
  const total = Number(panel[1])
  const footers = body.filter(line => /^  - generic: .*件\s*\/\s*.*件$/u.test(line))
  if (!total || !footers.length || !footers.every(line =>
      new RegExp('^  - generic: 1[~〜]' + total + '件\\s*/\\s*' + total + '件$','u').test(line))) return incomplete('page_range')
  const navigation = body.filter(line => line.trimStart().startsWith('- menuitemradio'))
  if (!navigation.length || navigation.some(line => line.trim() !== '- menuitemradio "Go to page 1" [checked]: "1"')) return incomplete('pagination')
  if (!body.includes('  - generic: 物件番号')) return incomplete('number_column')
  const seenIds = []
  for (const [i, line] of body.entries()) {
    if (line !== '  - checkbox' && line !== '  - checkbox [checked]') continue
    const ordinal = /^  - generic: "(\d+)"$/u.exec(body[i - 1] ?? '')
    const id = /^  - generic: "(\d{12})"$/u.exec(body[i + 1] ?? '')
    if (!ordinal || Number(ordinal[1]) !== seenIds.length + 1 || !id ||
        body[i + 2] !== '  - generic: 中古マンション') return incomplete('property_row')
    seenIds.push(id[1])
  }
  if (seenIds.length !== total || new Set(seenIds).size !== total) return incomplete('row_count')
  return { status: 'single_page_observed', total, seenIds, evidence }
}
