# 住まいAgent · Apple Silicon Mac / Google Chrome / Codex

请让 Codex 在经纪人指定的空项目中操作。经纪人本人确认 Chrome 扩展权限并处理 REINS 登录。需要已安装 Google Chrome 和能够本地执行及读图的 Codex。

1. 使用系统的 `uname -m` 与 `sw_vers` 确认 Apple Silicon macOS，核对下载文件的字节数与 SHA-256，再用系统 tar 解压。按官网指令校验后，使用原包所附的 Node，无需 Homebrew。在解压目录运行 `./package/runtime/node ./install.mjs "$projectPath" Codex`，从 JSON 返回值取得 node、client 和 skill 的绝对路径。
2. 执行 `"$node" "$client" "$projectPath" status`。尚未接入时，执行 `"$node" "$client" "$projectPath" open-store`。在案件专用 Chrome 中由 Codex 选择「添加至 Chrome」，由经纪人确认权限。使用原公开条目 Sumai Agent，ID 为 hoadgoaopafcjbgabnlbannhnfoghbld，所需版本为 0.4.53.1。安装受管理策略或系统安全设置阻止时，记录实际提示。
3. 执行 `"$node" "$client" "$projectPath" connect` 并轮询 status。只有本案 `connected=true` 才报告就绪。保持连接标签开启，读取返回的项目 SKILL.md，在同一对话受理客户需求。退出后可从相同项目重新连接。REINS 登录、验证码、规程由本人处理。
4. 列表、详情、原图在本用户的案件目录保存，结果链接可从案件入口继续打开。PDF 首图由 macOS 系统 PDFKit 在本机生成。只读后续页时，可在案件私有目录运行 `render-pdf-mac --page N < original.pdf > page-N.jpg`，随后实际查看该页。对外介绍前复核挂牌时效与可介绍状态。
