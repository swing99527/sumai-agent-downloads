import { createHash } from 'node:crypto'
import { spawnSync } from 'node:child_process'
import { createReadStream } from 'node:fs'
import { cp, lstat, mkdir, mkdtemp, readFile, readdir, realpath, rename, rm } from 'node:fs/promises'
import path from 'node:path'

const source = path.join(import.meta.dirname, 'package')
const mac = process.platform === 'darwin' && process.arch === 'arm64'
const nodeName = mac ? 'node' : 'node.exe'
async function sha(file) {
  const hash = createHash('sha256')
  for await (const chunk of createReadStream(file)) hash.update(chunk)
  return hash.digest('hex')
}

async function entries(dir, prefix = '') {
  const files = []
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    const name = prefix + entry.name
    if (entry.isDirectory()) files.push(...await entries(path.join(dir, entry.name), name + '/'))
    else if (entry.isFile()) files.push(name)
    else throw new Error('Linked or unsupported entry: ' + name)
  }
  return files
}

async function verify(dir, manifest) {
  if (!(await lstat(dir)).isDirectory()) throw new Error('Expected a project-local directory: ' + dir)
  const files = await entries(dir)
  if (files.length !== Object.keys(manifest).length) throw new Error('Unexpected install contents: ' + dir)
  for (const name of files) {
    if (!Object.hasOwn(manifest, name) || await sha(path.join(dir, name)) !== manifest[name]) {
      throw new Error('File verification failed: ' + name)
    }
  }
  const node = path.join(dir, 'runtime', nodeName)
  for (const args of [['--version'], [path.join(dir, 'scripts', 'toolkit.mjs'), '--help']]) {
    const result = spawnSync(node, args, { windowsHide: true, encoding: 'utf8' })
    if (result.status !== 0 || !result.stdout.trim() || (args.length === 1 && result.stdout.trim() !== 'v24.22.3')) {
      throw new Error('Self-test failed: ' + args.at(-1) + ' ' + (result.stderr || ''))
    }
  }
}

async function main() {
  const [project, host = 'Codex', ...rest] = process.argv.slice(2)
  const supported = mac ? host === 'Codex' : process.platform === 'win32' && process.arch === 'x64' && ['Codex', 'Claude'].includes(host)
  if (!project || rest.length || !supported) {
    throw new Error('Use the matching Windows x64 or Apple Silicon package. On macOS select Codex.')
  }
  if (!(await lstat(project)).isDirectory()) throw new Error('Choose an existing project directory.')
  const inventory = path.join(import.meta.dirname, 'files.json')
  if (await sha(inventory) !== '3b0d401f6bd89ee00aebd72061d6a421e8edc5e1002ace71987608082f99d900') throw new Error('Inventory verification failed.')
  const manifest = JSON.parse(await readFile(inventory, 'utf8'))
  const scope = path.join(await realpath(project), host === 'Claude' ? '.claude' : '.agents')
  const skills = path.join(scope, 'skills')
  for (const folder of [scope, skills]) {
    await mkdir(folder, { recursive: true })
    if (!(await lstat(folder)).isDirectory()) throw new Error('Linked skill directory: ' + folder)
  }
  const dest = path.join(skills, 'sumai-property-toolkit')
  const existing = await lstat(dest).catch(error => {
    if (error.code !== 'ENOENT') throw error
  })
  if (existing) await verify(dest, manifest)
  else {
    const stage = await mkdtemp(path.join(scope, 'sumai-stage-'))
    const unpacked = path.join(stage, 'package')
    try {
      await cp(source, unpacked, { recursive: true, force: false, errorOnExist: true })
      await verify(unpacked, manifest)
      await rename(unpacked, dest)
    } finally {
      await rm(stage, { recursive: true, force: true })
    }
  }
  console.log(JSON.stringify({ status: existing ? 'already-installed' : 'installed',
    candidate: '20261116-25', agent: host, skill: path.join(dest, 'SKILL.md'),
    node: path.join(dest, 'runtime', nodeName), browser: 'requires-authorized-browser-check' }))
}
main().catch(error => { console.error(error.message); process.exitCode = 1 })
