# 住まいAgent Chrome 公式ストア版

Windows 11 x64。展開フォルダーで同梱の Node を使い `& .\package\runtime\node.exe .\install.mjs $projectPath Codex` を実行します。以降はインストール結果の node、client の絶対パスを使います。

1. `& $node $client $projectPath open-store` で案件専用 Chrome の公式ストアを開きます。Agent が「Chrome に追加」を選択し、Chrome が表示する権限と「拡張機能を追加」の確認は本人に任せます。すでに導入済みなら接続に進みます。
2. `& $node $client $projectPath connect` で案件に接続します。続けて `& $node $client $projectPath status` を呼び、connected=true を確認します。ストアの配布版が 0.4.53.1 未満、組織のポリシーで禁止、または接続タブが利用できない場合は、その理由と未完了の状態を伝えてください。
3. 接続タブを開いたまま同じ対話で希望条件を受け取ります。REINS ログイン・規程の確認は必要なときに本人が行います。既存のサイドパネル機能は従来通り利用できます。
