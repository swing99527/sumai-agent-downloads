import { createHash, generateKeyPairSync, randomBytes } from 'node:crypto'
import { spawnSync } from 'node:child_process'
import { copyFile, cp, lstat, mkdir, mkdtemp, readFile, realpath, rename, rm, writeFile } from 'node:fs/promises'
import path from 'node:path'

export async function projectData(project, store=false) {
  const full = await realpath(project)
  const key = createHash('sha256').update(full.toLowerCase()).digest('hex').slice(0,24)
  return path.join(process.env.LOCALAPPDATA,'SumaiAgent',store?'station-27':'station-26',key)
}
export const storeId='hoadgoaopafcjbgabnlbannhnfoghbld'
export async function setup(project, skill, store=false) {
  const root = await projectData(project,store)
  const extension = path.join(root,'extension'), exchange=path.join(root,'exchange')
  const manifest = path.join(root,'host.json')
  const parent = path.dirname(root)
  await mkdir(parent,{recursive:true})
  const found = await lstat(root).catch(e=>{if(e.code!=='ENOENT')throw e})
  if (!found) {
    const stage=await mkdtemp(path.join(parent,'install-'))
    try {
      // Protect the case before creating any records in it.
      const user=spawnSync('whoami.exe',['/user','/fo','csv','/nh'],{encoding:'utf8',windowsHide:true})
      const sid=user.stdout?.match(/S-1-5-[\d-]+/)?.[0]
      if(!sid || user.status!==0)throw Error('Cannot identify the Windows user.')
      const acl=spawnSync('icacls.exe',[stage,'/inheritance:r','/grant:r','*'+sid+':(OI)(CI)F','*S-1-5-18:(OI)(CI)F','*S-1-5-32-544:(OI)(CI)F'],{windowsHide:true})
      if(acl.status!==0)throw Error('Cannot protect the local case directory.')
      let id=storeId
      if(!store){
        await cp(path.join(skill,'browser','extension'),path.join(stage,'extension'),{recursive:true})
        const key=generateKeyPairSync('rsa',{modulusLength:2048}).publicKey.export({format:'der',type:'spki'})
        id=Array.from(createHash('sha256').update(key).digest('hex').slice(0,32),c=>String.fromCharCode(97+parseInt(c,16))).join('')
        const file=path.join(stage,'extension','manifest.json')
        const m=JSON.parse(await readFile(file,'utf8'))
        await writeFile(file,JSON.stringify({...m,key:key.toString('base64')}))
      }
      await mkdir(path.join(stage,'exchange'))
      await writeFile(path.join(stage,'exchange','pair.json'),JSON.stringify({extensionId:id,query:null,scopeMode:'first-search',channel:randomBytes(32).toString('hex')}))
      if(!store){
      await copyFile(path.join(skill,'runtime','node.exe'),path.join(stage,'node.exe'))
      await copyFile(path.join(skill,'browser','native.mjs'),path.join(stage,'native.mjs'))
      await writeFile(path.join(stage,'host.cmd'),'@echo off\r\n"%~dp0node.exe" "%~dp0native.mjs" "%~dp0exchange" "%~1"\r\n','ascii')
      await writeFile(path.join(stage,'host.json'),JSON.stringify({name:'jp.sumai.project_'+id,description:'Sumai REINS project trial',path:path.join(root,'host.cmd'),type:'stdio',allowed_origins:['chrome-extension://'+id+'/']}))
      }
      await rename(stage,root)
    } finally {await rm(stage,{recursive:true,force:true})}
  } else if (!found.isDirectory()) throw Error('Unexpected local case path.')
  const pair=JSON.parse(await readFile(path.join(exchange,'pair.json'),'utf8'))
  if(store){
    if(pair.extensionId!==storeId || pair.scopeMode!=='first-search')throw Error('Conflicting store project.')
    return {extensionId:storeId,exchange,profile:path.join(root,'browser-profile'),storeUrl:'https://chromewebstore.google.com/detail/'+storeId}
  }
  const host=JSON.parse(await readFile(manifest,'utf8'))
  if(!/^[a-p]{32}$/.test(pair.extensionId)||host.name!=='jp.sumai.project_'+pair.extensionId||host.path!==path.join(root,'host.cmd'))throw Error('Conflicting project registration.')
  const reg='HKCU\\Software\\Google\\Chrome\\NativeMessagingHosts\\'+host.name
  const existing=spawnSync('reg.exe',['query',reg,'/ve'],{encoding:'utf8',windowsHide:true})
  if(existing.status===0 && !existing.stdout.toLowerCase().includes('REG_SZ    '.toLowerCase()+manifest.toLowerCase()))throw Error('Native host already registered at another location.')
  if(existing.status!==0 && spawnSync('reg.exe',['add',reg,'/ve','/t','REG_SZ','/d',manifest,'/f'],{windowsHide:true}).status!==0)throw Error('Current-user native registration failed.')
  return {extension,extensionId:pair.extensionId,exchange,profile:path.join(root,'browser-profile'),registry:reg}
}
